import app from "./app.js";

Deno.serve(app.fetch);
// // 
// # {"database":"db9bfcb50f953d44","username":"db9bfcb50f953d44","password":"dbff0047fccb0c42"}