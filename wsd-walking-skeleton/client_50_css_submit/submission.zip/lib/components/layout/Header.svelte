<header class="flex items-center bg-primary-100 p-4 mb-6">
  <h1 class="text-xl text-primary-900">TODOS</h1>
  <nav class="ml-4">
    <ul class="flex space-x-4">
      <li><a class="anchor" href="#">Link 1</a></li>
      <li><a class="anchor" href="#">Link 2</a></li>
      <li><a class="anchor" href="#">Link 3</a></li>
    </ul>
  </nav>
</header>
