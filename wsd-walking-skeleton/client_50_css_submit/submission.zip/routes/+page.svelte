<script>
  import Todos from "$lib/components/Todos.svelte";
  import { fade } from "svelte/transition";

</script>

<Todos />