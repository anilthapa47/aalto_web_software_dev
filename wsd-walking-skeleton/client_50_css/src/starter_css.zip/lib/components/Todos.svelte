<script>
  import TodoForm from "./TodoForm.svelte";
  import TodoList from "./TodoList.svelte";
</script>

<h1>Todos</h1>

<h2>Add Todo</h2>

<TodoForm />

<h2>Existing todos</h2>

<TodoList />
