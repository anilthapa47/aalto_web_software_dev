<footer class="p-4 border-t-2">
    <p class="text-center">Check todo forms</p>
</footer>
