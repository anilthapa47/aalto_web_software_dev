<header class="flex items-center bg-primary-100 p-4 mb-6">
  <h1 class="text-xl text-primary-900">TODOS</h1>
  <nav class="ml-4">
    <ul class="flex space-x-4">
      <li>
        <a href="/" class="text-white hover:text-yellow-300 transition">Home</a>
      </li>
      <li>
        <a href="/courses" class="text-white hover:text-yellow-300 transition"
          >Courses</a
        >
      </li>
    </ul>
  </nav>
</header>
