<!--
<script>
  import Todos from "$lib/components/Questions.svelte";
  import { fade } from "svelte/transition";

</script>

<Todos />
-->

<div class="flex flex-col items-center mt-10">
  <h1 class="text-3xl font-bold text-gray-800">Welcome!</h1>

</div>
