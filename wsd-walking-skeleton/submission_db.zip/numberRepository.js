let number = 0;

const setNumber = (n) => number = n;


const getNumber = () => {
    return number;
}

export { setNumber };
export { getNumber };